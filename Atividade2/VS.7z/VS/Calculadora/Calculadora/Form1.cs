﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        double FirstValor, SecondValor, Result;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            Result = FirstValor * SecondValor;

            resultOutput.Text = Result.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            Result = FirstValor / SecondValor;

            resultOutput.Text = Result.ToString();
        }

        private void firstInput_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(firstInput.Text, out FirstValor))
            {
                // errorProvider1.SetError(firstInput, "teste"):
                MessageBox.Show("Número Inválido!");
                firstInput.Focus();
            }
        }

        private void secondInput_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(secondInput.Text, out SecondValor))
            {
                // errorProvider1.SetError(firstInput, "teste"):
                MessageBox.Show("Número Inválido!");
                secondInput.Focus();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            firstInput.Clear();
            secondInput.Clear();
            resultOutput.Clear();
        }

        private void btnSum_Click(object sender, EventArgs e)
        {

            Result = FirstValor + SecondValor;

            resultOutput.Text = Result.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Result = FirstValor - SecondValor;
            resultOutput.Text = Result.ToString();
        }
    }
}
