﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        double Weight, Height, Imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            mskbxHeight.Clear();
            mskbxWeight.Clear();
            txtImc.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbxWeight_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxWeight.Text, out Weight))
            {
                MessageBox.Show("Número inválido!");
                mskbxWeight.Focus();
            }
        }

        private void mskbxHeight_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxHeight.Text, out Height))
            {
                MessageBox.Show("Número Inválido!");
                mskbxHeight.Focus();
            }
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Imc = Weight / Math.Pow(Height,2);
            Imc = Math.Round(Imc, 1);
            txtImc.Text = Imc.ToString();
        
            if (Imc < 18.5)
            {
                MessageBox.Show("Classificação: Magreza \nGrau de Obesidade: 0");
            }
            else
            {
                if (Imc >= 18.5 & Imc <= 24.9)
                {
                    MessageBox.Show("Classificação: Normal \nGrau de Obesidade: 0");
                }
                else
                {
                    if (Imc >= 25 & Imc <= 29.9)
                    {
                        MessageBox.Show("Classificação: Sobrepeso \nGrau de Obesidade: 1");
                    }
                    else
                    {
                        if (Imc >= 30 & Imc <= 39.9)
                        {
                            MessageBox.Show("Classificação: Obesidade \nGrau de Obesidade: 2");
                        }
                        else
                        {
                            MessageBox.Show("Classificação: Obesidade Grave \nGrau de Obesidade: 3");
                        }
                    }
                }
            }

        }
    }
}
