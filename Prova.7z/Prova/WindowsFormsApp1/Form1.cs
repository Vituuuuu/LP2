﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[20, 4];
            string auxiliar;
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o valor da semana {j + 1} do mês {i + 1}:");
                    

                }
            }

            string mensagem = "";
          
            double totalmes = 0;

            for (int i = 0; i < 20; i++)
            {

                for (int j = 0; j < 4; j++)
                {


                    totalmes += matriz[i, j];

                }
                
                mensagem = $"Mês {i + 1}: Total do mês: {totalmes.ToString("C")}\n";
                listDados.Items.Add(mensagem);
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listDados.Items.Clear();
        }
    }
}
